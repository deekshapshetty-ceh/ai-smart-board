// db.js (or your filename)
import pkg from 'pg';
const { Pool } = pkg;

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'whiteboard',
  password: 'root',
  port: 5432,
});

export default pool;
