import express from 'express';
import bodyParser from 'body-parser';
import fs from 'fs/promises';
import run from './run.js';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import pool from './db.js';

const app = express();
const port = process.env.PORT || 8000;
const JWT_SECRET = 'your_jwt_secret_key'; // Replace with a secure key in production

const corsOptions = {
  origin: 'http://localhost:5173',
  credentials: true,
};

app.set('view engine', 'ejs');
app.use(cors(corsOptions));
app.use(express.static('public'));
app.use(express.static('views'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json({ limit: '10mb' }));

// Middleware to verify JWT
const authenticateToken = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  if (!token) {
    return res.status(401).send({ error: 'Access token required.' });
  }

  try {
    const user = jwt.verify(token, JWT_SECRET);
    req.user = user;
    next();
  } catch (err) {
    return res.status(403).send({ error: 'Invalid or expired token.' });
  }
};

// Signup route
app.post('/signup', async (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).send({ error: 'All fields are required.' });
  }

  try {
    // Check if user already exists
    const userExists = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (userExists.rows.length > 0) {
      return res.status(400).send({ error: 'User already exists.' });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Insert user into database
    const result = await pool.query(
      'INSERT INTO users (name, email, password) VALUES ($1, $2, $3) RETURNING id, name, email',
      [name, email, hashedPassword]
    );

    // Generate JWT
    const user = result.rows[0];
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '1h' });

    res.status(201).send({ token, user: { id: user.id, name: user.name, email: user.email } });
  } catch (err) {
    console.error('Error during signup:', err);
    res.status(500).send({ error: 'Server error.' });
  }
});

// Login route
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).send({ error: 'Email and password are required.' });
  }

  try {
    // Check if user exists
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (result.rows.length === 0) {
      return res.status(400).send({ error: 'Invalid credentials.' });
    }

    const user = result.rows[0];

    // Verify password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).send({ error: 'Invalid credentials.' });
    }

    // Generate JWT
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '1h' });

    res.send({ token, user: { id: user.id, name: user.name, email: user.email } });
  } catch (err) {
    console.error('Error during login:', err);
    res.status(500).send({ error: 'Server error.' });
  }
});

// Protected route for saving drawing
app.post('/save-drawing', authenticateToken, async (req, res) => {
  const { image } = req.body;
  if (!image) {
    return res.status(400).send({ error: 'No image data provided.' });
  }

  // Remove the 'data:image/png;base64,' prefix
  const base64Data = image.replace(/^data:image\/png;base64,/, '');

  try {
    // Save the image to the server
    await fs.writeFile('./images/whiteboard-drawing.png', base64Data, 'base64');
    let result = await run();
    res.send({ result });
  } catch (err) {
    console.error('Error saving image:', err);
    res.status(500).send({ error: 'Failed to save image.' });
  }
});

app.get('/', (req, res) => {
  res.render('index.ejs');
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});