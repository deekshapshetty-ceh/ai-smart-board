const canvas = document.getElementById('whiteboard');
const ctx = canvas.getContext('2d');

// Set canvas resolution to match displayed size
canvas.width = canvas.offsetWidth;
canvas.height = canvas.offsetHeight;

let painting = false;
let brushColor = '#000000';
let brushSize = 5;
let erasing = false;

// Get the border width
const borderWidth = parseInt(getComputedStyle(canvas).borderWidth) || 0;

// Start drawing (mouse)
const startPainting = (e) => {
    painting = true;
    draw(e);
};

// Stop drawing (mouse)
const stopPainting = () => {
    painting = false;
    ctx.beginPath();
};

// Draw on the canvas (mouse)
const draw = (e) => {
    if (!painting) return;

    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.strokeStyle = erasing ? '#fff' : brushColor;

    // Adjust coordinates for border
    const x = e.offsetX - borderWidth;
    const y = e.offsetY - borderWidth;

    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
};

// Mouse event listeners
canvas.addEventListener('mousedown', startPainting);
canvas.addEventListener('mouseup', stopPainting);
canvas.addEventListener('mousemove', draw);

// Start drawing (touch)
const startTouch = (e) => {
    painting = true;
    drawTouch(e);
};

// Stop drawing (touch)
const stopTouch = () => {
    painting = false;
    ctx.beginPath();
};

// Draw on the canvas (touch)
const drawTouch = (e) => {
    if (!painting) return;

    e.preventDefault();
    const touch = e.touches[0];

    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.strokeStyle = erasing ? '#fff' : brushColor;

    // Adjust coordinates for border
    const rect = canvas.getBoundingClientRect();
    const x = touch.clientX - rect.left - borderWidth;
    const y = touch.clientY - rect.top - borderWidth;

    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
};

// Touch event listeners
canvas.addEventListener('touchstart', startTouch);
canvas.addEventListener('touchend', stopTouch);
canvas.addEventListener('touchmove', drawTouch);

// Clear button functionality
document.getElementById('clear-btn').addEventListener('click', () => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
});

// Update brush color
document.getElementById('color-picker').addEventListener('input', (e) => {
    brushColor = e.target.value;
    erasing = false;
});

// Update brush size
document.getElementById('brush-size').addEventListener('input', (e) => {
    brushSize = e.target.value;
});

// Eraser button functionality
document.getElementById('eraser-btn').addEventListener('click', () => {
    erasing = true;
});

// Save button functionality
const saveButton = document.getElementById('save-btn');
const loader = document.getElementById('loader');
const ans = document.getElementById('ans');

saveButton.addEventListener('click', () => {
    loader.style.display = 'flex';
    saveButton.disabled = true;

    const offscreenCanvas = document.createElement('canvas');
    const offscreenCtx = offscreenCanvas.getContext('2d');

    offscreenCanvas.width = canvas.width;
    offscreenCanvas.height = canvas.height;

    offscreenCtx.fillStyle = 'white';
    offscreenCtx.fillRect(0, 0, offscreenCanvas.width, offscreenCanvas.height);
    offscreenCtx.drawImage(canvas, 0, 0);

    const dataURL = offscreenCanvas.toDataURL('image/png');
    const payload = { image: dataURL };

    fetch('/save-drawing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
    })
        .then((response) => response.json())
        .then((data) => {
            loader.style.display = 'none';
            saveButton.disabled = false;
            ans.innerHTML = data.result;
        })
        .catch((error) => {
            console.error('Error saving drawing:', error);
            alert('Failed to save drawing.');
            loader.style.display = 'none';
            saveButton.disabled = false;
        });
});

// File input for uploading images
const fileUploadInput = document.getElementById('file-upload');
fileUploadInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();

    reader.onload = () => {
        const img = new Image();
        img.onload = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        };
        img.src = reader.result;
    };

    reader.readAsDataURL(file);
});

// Drag and Drop functionality for images
const dragDropArea = document.getElementById('drag-drop-area');

dragDropArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    dragDropArea.classList.add('drag-over');
});

dragDropArea.addEventListener('dragleave', () => {
    dragDropArea.classList.remove('drag-over');
});

dragDropArea.addEventListener('drop', (e) => {
    e.preventDefault();
    dragDropArea.classList.remove('drag-over');

    const file = e.dataTransfer.files[0];
    if (!file || !file.type.startsWith('image/')) return;

    const reader = new FileReader();

    reader.onload = () => {
        const img = new Image();
        img.onload = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        };
        img.src = reader.result;
    };

    reader.readAsDataURL(file);
});