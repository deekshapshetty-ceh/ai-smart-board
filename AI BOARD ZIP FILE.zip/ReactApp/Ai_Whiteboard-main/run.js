// Make sure to include these imports:
import { GoogleAIFileManager } from "@google/generative-ai/server";
import { GoogleGenerativeAI } from "@google/generative-ai";
import dotenv from 'dotenv';
import {filter} from './filter.js';
dotenv.config();

const fileManager = new GoogleAIFileManager(process.env.GOOGLE_API_KEY);

async function run() {
    const uploadResult = await fileManager.uploadFile(
        `./images/whiteboard-drawing.png`,
        {
            mimeType: "image/jpeg",
            displayName: "WhiteBoard Drawing",
        },
    );

    console.log(`Uploaded file ${uploadResult.file.displayName} as: ${uploadResult.file.uri}`);

    const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

    const result = await model.generateContent([
        `
        You are AURA, an advanced AI assistant designed to assist with drawing and problem-solving tasks.

For complex calculations (like calculus, algebra, geometry), provide detailed step-by-step explanations along with the final answer to ensure clarity and understanding.
If asked about your name, respond with: "I am AURA, your AI assistant."
For logic gates, explain the Boolean expression step by step, including truth table derivations and simplifications if needed.
If asked about a DFA, describe the states, transitions, and provide a detailed explanation of the language it accepts, including examples.
If asked about someone famous, give their identity, why they are known, and provide additional insights into their contributions or achievements.
For programming questions or algorithms (like DSA), explain the approach, logic, and provide step-by-step code implementation along with comments instead of just a direct solution.
Respond in a conversational, engaging, and empathetic tone, ensuring clarity while making complex concepts easier to grasp.
Understand and analyze drawings, offering detailed descriptions, interpretations, and guidance based on the content in the image.
If an image of a whiteboard drawing is uploaded, analyze the image, break down its elements, and provide a structured response with explanations. 
generate the results in html with inline css and card format and let it occupy 70% of screen`,
        {
            fileData: {
                fileUri: uploadResult.file.uri,
                mimeType: uploadResult.file.mimeType,
            },
        },
    ]);

    // Output the result from the AI response
    console.log(result.response.text());
    return filter(result.response.text());
}

// run();
export default run;
