import { useState, useRef, useEffect } from 'react';
import { Routes, Route, useNavigate, Navigate } from 'react-router-dom';
import Login from './Login';
import Signup from './Signup';
import Navbar from './Navbar';
import './App.css';

function Whiteboard() {
  const canvasRef = useRef(null);
  const [isPainting, setIsPainting] = useState(false);
  const [brushColor, setBrushColor] = useState('#000000');
  const [brushSize, setBrushSize] = useState(5);
  const [brushType, setBrushType] = useState('round');
  const [tool, setTool] = useState('brush');
  const [isLoading, setIsLoading] = useState(false);
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [startPos, setStartPos] = useState(null);
  const [currentStroke, setCurrentStroke] = useState([]);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [showSizeOverlay, setShowSizeOverlay] = useState(false);
  const [sizeOverlayTimeout, setSizeOverlayTimeout] = useState(null);
  const [history, setHistory] = useState([]); // For stroke eraser
  const resultRef = useRef(null);
  const offscreenCanvasRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');

    offscreenCanvasRef.current = document.createElement('canvas');
    const offscreenCtx = offscreenCanvasRef.current.getContext('2d');

    const setCanvasDimensions = () => {
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = canvas.width;
      tempCanvas.height = canvas.height;
      const tempCtx = tempCanvas.getContext('2d');
      tempCtx.drawImage(canvas, 0, 0);

      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      offscreenCanvasRef.current.width = canvas.width;
      offscreenCanvasRef.current.height = canvas.height;

      ctx.drawImage(tempCanvas, 0, 0);
      offscreenCtx.drawImage(tempCanvas, 0, 0);
    };

    setCanvasDimensions();

    const handleResize = () => {
      setCanvasDimensions();
      redrawCanvas();
    };

    window.addEventListener('resize', handleResize);

    const borderWidth = parseInt(getComputedStyle(canvas).borderWidth) || 0;

    const getCanvasPosition = (e, borderWidth) => {
      const rect = canvas.getBoundingClientRect();
      return {
        x: (e.clientX - rect.left - borderWidth) / zoomLevel,
        y: (e.clientY - rect.top - borderWidth) / zoomLevel,
      };
    };

    const getTouchPosition = (e, borderWidth) => {
      const touch = e.touches[0];
      const rect = canvas.getBoundingClientRect();
      return {
        x: (touch.clientX - rect.left - borderWidth) / zoomLevel,
        y: (touch.clientY - rect.top - borderWidth) / zoomLevel,
      };
    };

    const startPainting = (e) => {
      setIsPainting(true);
      const pos = getCanvasPosition(e, borderWidth);
      setStartPos(pos);

      if (tool === 'brush' || tool === 'eraser') {
        setCurrentStroke([pos]);
        draw(e);
      } else if (tool === 'fill') {
        handleFill(pos);
      } else if (tool === 'zoom-in' || tool === 'zoom-out') {
        handleZoom(pos);
      } else if (['rectangle', 'circle', 'line'].includes(tool)) {
        // Save the current state to offscreen canvas before starting to draw the shape
        offscreenCtx.drawImage(canvas, 0, 0);
      } else if (tool === 'area-eraser') {
        // For area eraser, we'll handle it in the draw function
      } else if (tool === 'stroke-eraser') {
        handleStrokeEraser(pos);
      }
    };

    const stopPainting = () => {
      if (!isPainting) return;
      setIsPainting(false);
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      const offscreenCtx = offscreenCanvasRef.current.getContext('2d');

      if (tool === 'brush' || tool === 'eraser') {
        addToHistory({
          type: 'stroke',
          points: currentStroke,
          color: tool === 'eraser' ? '#ffffff' : brushColor,
          size: brushSize,
          brushType: brushType,
        });
        setCurrentStroke([]);
      } else if (['rectangle', 'circle', 'line'].includes(tool) && startPos) {
        // After drawing the shape, update the offscreen canvas
        offscreenCtx.drawImage(canvas, 0, 0);
      } else if (tool === 'area-eraser' && startPos) {
        const endPos = startPos; // Since we're handling it in draw
        const x = Math.min(startPos.x, endPos.x);
        const y = Math.min(startPos.y, endPos.y);
        const width = Math.abs(endPos.x - startPos.x);
        const height = Math.abs(endPos.y - startPos.y);
        ctx.clearRect(x, y, width, height);
        offscreenCtx.clearRect(x, y, width, height);
      }
      ctx.beginPath();
      setStartPos(null);
    };

    const draw = (e) => {
      if (!isPainting) return;
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      const pos = getCanvasPosition(e, borderWidth);

      ctx.save();
      ctx.scale(zoomLevel, zoomLevel);

      if (tool === 'brush' || tool === 'eraser') {
        ctx.lineWidth = brushSize;
        ctx.lineCap = brushType;
        ctx.strokeStyle = tool === 'eraser' ? '#ffffff' : brushColor;

        setCurrentStroke([...currentStroke, pos]);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(pos.x, pos.y);
      } else if (['rectangle', 'circle', 'line'].includes(tool)) {
        // Restore the canvas to the state before the drag
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(offscreenCanvasRef.current, 0, 0);

        // Draw the current shape
        ctx.lineWidth = brushSize;
        ctx.strokeStyle = brushColor;
        ctx.beginPath();

        if (tool === 'rectangle') {
          ctx.strokeRect(startPos.x, startPos.y, pos.x - startPos.x, pos.y - startPos.y);
        } else if (tool === 'circle') {
          const radius = Math.sqrt(
            Math.pow(pos.x - startPos.x, 2) + Math.pow(pos.y - startPos.y, 2)
          );
          ctx.arc(startPos.x, startPos.y, radius, 0, 2 * Math.PI);
          ctx.stroke();
        } else if (tool === 'line') {
          ctx.moveTo(startPos.x, startPos.y);
          ctx.lineTo(pos.x, pos.y);
          ctx.stroke();
        }
      } else if (tool === 'area-eraser') {
        // For area eraser, clear the area directly
        const x = Math.min(startPos.x, pos.x);
        const y = Math.min(startPos.y, pos.y);
        const width = Math.abs(pos.x - startPos.x);
        const height = Math.abs(pos.y - startPos.y);
        ctx.clearRect(x, y, width, height);
        setStartPos(pos); // Update start position for continuous erasing
      }
      ctx.restore();
    };

    const handleStrokeEraser = (pos) => {
      const strokeIndex = findStrokeNearPoint(pos);
      if (strokeIndex !== -1) {
        const newHistory = [...history];
        newHistory.splice(strokeIndex, 1);
        setHistory(newHistory);
        redrawCanvas();
      }
    };

    const startTouch = (e) => {
      setIsPainting(true);
      const pos = getTouchPosition(e, borderWidth);
      setStartPos(pos);

      if (tool === 'brush' || tool === 'eraser') {
        setCurrentStroke([pos]);
        drawTouch(e);
      } else if (tool === 'fill') {
        handleFill(pos);
      } else if (tool === 'zoom-in' || tool === 'zoom-out') {
        handleZoom(pos);
      } else if (tool === 'stroke-eraser') {
        handleStrokeEraser(pos);
      }
    };

    const stopTouch = () => {
      stopPainting();
    };

    const drawTouch = (e) => {
      if (!isPainting) return;
      e.preventDefault();
      const pos = getTouchPosition(e, borderWidth);
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');

      ctx.save();
      ctx.scale(zoomLevel, zoomLevel);

      if (tool === 'brush' || tool === 'eraser') {
        ctx.lineWidth = brushSize;
        ctx.lineCap = brushType;
        ctx.strokeStyle = tool === 'eraser' ? '#ffffff' : brushColor;

        setCurrentStroke([...currentStroke, pos]);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(pos.x, pos.y);
      } else if (['rectangle', 'circle', 'line'].includes(tool)) {
        // Restore the canvas to the state before the drag
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(offscreenCanvasRef.current, 0, 0);

        // Draw the current shape
        ctx.lineWidth = brushSize;
        ctx.strokeStyle = brushColor;
        ctx.beginPath();

        if (tool === 'rectangle') {
          ctx.strokeRect(startPos.x, startPos.y, pos.x - startPos.x, pos.y - startPos.y);
        } else if (tool === 'circle') {
          const radius = Math.sqrt(
            Math.pow(pos.x - startPos.x, 2) + Math.pow(pos.y - startPos.y, 2)
          );
          ctx.arc(startPos.x, startPos.y, radius, 0, 2 * Math.PI);
          ctx.stroke();
        } else if (tool === 'line') {
          ctx.moveTo(startPos.x, startPos.y);
          ctx.lineTo(pos.x, pos.y);
          ctx.stroke();
        }
      } else if (tool === 'area-eraser') {
        const x = Math.min(startPos.x, pos.x);
        const y = Math.min(startPos.y, pos.y);
        const width = Math.abs(pos.x - startPos.x);
        const height = Math.abs(pos.y - startPos.y);
        ctx.clearRect(x, y, width, height);
        setStartPos(pos);
      }
      ctx.restore();
    };

    const addToHistory = (action) => {
      setHistory([...history, action]);
    };

    const redrawCanvas = () => {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.save();
      ctx.scale(zoomLevel, zoomLevel);

      for (const action of history) {
        if (action.type === 'stroke') {
          ctx.lineWidth = action.size;
          ctx.lineCap = action.brushType;
          ctx.strokeStyle = action.color;
          ctx.beginPath();
          for (let j = 0; j < action.points.length; j++) {
            const { x, y } = action.points[j];
            if (j === 0) {
              ctx.moveTo(x, y);
            } else {
              ctx.lineTo(x, y);
              ctx.stroke();
              ctx.beginPath();
              ctx.moveTo(x, y);
            }
          }
        } else if (action.type === 'image') {
          ctx.drawImage(action.img, action.x, action.y, action.width, action.height);
        }
      }
      ctx.restore();
    };

    const findStrokeNearPoint = (pos) => {
      let minDistance = Infinity;
      let closestStrokeIndex = -1;
      for (let i = history.length - 1; i >= 0; i--) {
        const action = history[i];
        if (action.type === 'stroke') {
          for (const point of action.points) {
            const distance = Math.sqrt(
              Math.pow(pos.x - point.x, 2) + Math.pow(pos.y - point.y, 2)
            );
            if (distance < minDistance && distance < 10) { // Threshold of 10 pixels
              minDistance = distance;
              closestStrokeIndex = i;
            }
          }
        }
      }
      return closestStrokeIndex;
    };

    const handleFill = (pos) => {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;
      const targetColor = getPixelColor(data, Math.floor(pos.x), Math.floor(pos.y), canvas.width);
      const fillColor = hexToRgb(brushColor);

      const tolerance = 10;
      if (colorMatch(targetColor, fillColor, tolerance)) return;

      const stack = [{ x: Math.floor(pos.x), y: Math.floor(pos.y) }];
      const visited = new Set();
      const width = canvas.width;
      const height = canvas.height;

      while (stack.length) {
        const { x, y } = stack.pop();
        const key = `${x},${y}`;
        if (visited.has(key) || x < 0 || x >= width || y < 0 || y >= height) continue;

        visited.add(key);
        const pixelColor = getPixelColor(data, x, y, width);
        if (colorMatch(pixelColor, targetColor, tolerance)) {
          setPixelColor(data, x, y, width, fillColor);
          stack.push({ x: x + 1, y });
          stack.push({ x: x - 1, y });
          stack.push({ x, y: y + 1 });
          stack.push({ x, y: y - 1 });
        }
      }

      ctx.putImageData(imageData, 0, 0);
      offscreenCanvasRef.current.getContext('2d').putImageData(imageData, 0, 0);
    };

    const colorMatch = (color1, color2, tolerance) => {
      return (
        Math.abs(color1.r - color2.r) <= tolerance &&
        Math.abs(color1.g - color2.g) <= tolerance &&
        Math.abs(color1.b - color2.b) <= tolerance
      );
    };

    const getPixelColor = (data, x, y, width) => {
      const index = (y * width + x) * 4;
      return {
        r: data[index],
        g: data[index + 1],
        b: data[index + 2],
        a: data[index + 3],
      };
    };

    const setPixelColor = (data, x, y, width, color) => {
      const index = (y * width + x) * 4;
      data[index] = color.r;
      data[index + 1] = color.g;
      data[index + 2] = color.b;
      data[index + 3] = 255;
    };

    const hexToRgb = (hex) => {
      const r = parseInt(hex.slice(1, 3), 16);
      const g = parseInt(hex.slice(3, 5), 16);
      const b = parseInt(hex.slice(5, 7), 16);
      return { r, g, b };
    };

    const handleZoom = (pos) => {
      if (tool === 'zoom-in') {
        setZoomLevel((prev) => Math.min(prev + 0.2, 3));
      } else if (tool === 'zoom-out') {
        setZoomLevel((prev) => Math.max(prev - 0.2, 0.5));
      }
      redrawCanvas();
    };

    const handleDragOver = (e) => {
      e.preventDefault();
      setIsDraggingOver(true);
    };

    const handleDragLeave = (e) => {
      e.preventDefault();
      setIsDraggingOver(false);
    };

    const handleDrop = (e) => {
      e.preventDefault();
      setIsDraggingOver(false);

      const file = e.dataTransfer.files[0];
      if (!file || !file.type.startsWith('image/')) return;

      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const canvas = canvasRef.current;
          const ctx = canvas.getContext('2d');
          const offscreenCtx = offscreenCanvasRef.current.getContext('2d');

          const rect = canvas.getBoundingClientRect();
          const x = (e.clientX - rect.left - borderWidth) / zoomLevel;
          const y = (e.clientY - rect.top - borderWidth) / zoomLevel;

          const maxWidth = canvas.width / zoomLevel - x;
          const maxHeight = canvas.height / zoomLevel - y;
          let imgWidth = img.width;
          let imgHeight = img.height;

          if (imgWidth > maxWidth || imgHeight > maxHeight) {
            const scale = Math.min(maxWidth / imgWidth, maxHeight / imgHeight);
            imgWidth *= scale;
            imgHeight *= scale;
          }

          ctx.drawImage(img, x, y, imgWidth, imgHeight);
          offscreenCtx.drawImage(img, x, y, imgWidth, imgHeight);
          addToHistory({ type: 'image', img, x, y, width: imgWidth, height: imgHeight });
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    };

    canvas.addEventListener('mousedown', startPainting);
    canvas.addEventListener('mouseup', stopPainting);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('touchstart', startTouch);
    canvas.addEventListener('touchend', stopTouch);
    canvas.addEventListener('touchmove', drawTouch);

    window.addEventListener('dragover', handleDragOver);
    window.addEventListener('dragleave', handleDragLeave);
    window.addEventListener('drop', handleDrop);

    return () => {
      canvas.removeEventListener('mousedown', startPainting);
      canvas.removeEventListener('mouseup', stopPainting);
      canvas.removeEventListener('mousemove', draw);
      canvas.removeEventListener('touchstart', startTouch);
      canvas.removeEventListener('touchend', stopTouch);
      canvas.removeEventListener('touchmove', drawTouch);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('dragover', handleDragOver);
      window.removeEventListener('dragleave', handleDragLeave);
      window.removeEventListener('drop', handleDrop);
    };
  }, [isPainting, brushColor, brushSize, brushType, tool, zoomLevel, history]);

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const offscreenCtx = offscreenCanvasRef.current.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    offscreenCtx.clearRect(0, 0, offscreenCanvasRef.current.width, offscreenCanvasRef.current.height);
    setHistory([]);
  };

  const selectTool = (newTool) => {
    setTool(newTool);
    if (['brush', 'rectangle', 'circle', 'line', 'fill'].includes(newTool)) {
      setBrushColor(brushColor);
    }
  };

  const handleColorChange = (e) => {
    setBrushColor(e.target.value);
    if (tool !== 'brush' && tool !== 'rectangle' && tool !== 'circle' && tool !== 'line' && tool !== 'fill' && tool !== 'stroke-eraser') {
      setTool('brush');
    }
  };

  const handleBrushSizeChange = (e) => {
    const newSize = e.target.value;
    setBrushSize(newSize);

    setShowSizeOverlay(true);
    if (sizeOverlayTimeout) {
      clearTimeout(sizeOverlayTimeout);
    }
    const timeout = setTimeout(() => {
      setShowSizeOverlay(false);
    }, 2000);
    setSizeOverlayTimeout(timeout);
  };

  const saveDrawing = () => {
    setIsLoading(true);
    const canvas = canvasRef.current;
    const offscreenCanvas = document.createElement('canvas');
    const offscreenCtx = offscreenCanvas.getContext('2d');

    offscreenCanvas.width = canvas.width;
    offscreenCanvas.height = canvas.height;

    offscreenCtx.fillStyle = 'white';
    offscreenCtx.fillRect(0, 0, offscreenCanvas.width, offscreenCanvas.height);
    offscreenCtx.drawImage(canvas, 0, 0);

    const dataURL = offscreenCanvas.toDataURL('image/png');
    const payload = { image: dataURL };
    const token = localStorage.getItem('token');

    fetch('http://localhost:8000/save-drawing', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify(payload),
    })
      .then((response) => response.json())
      .then((data) => {
        setIsLoading(false);
        if (data.error) {
          alert(data.error);
          if (data.error.includes('token')) {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            navigate('/login');
          }
          return;
        }
        resultRef.current.innerHTML = data.result;
        resultRef.current.scrollIntoView({ behavior: 'smooth' });
      })
      .catch((error) => {
        console.error('Error saving drawing:', error);
        alert('Failed to save drawing.');
        setIsLoading(false);
      });
  };

  return (
    <div>
      <Navbar onImageUpload={(file) => {
        const reader = new FileReader();
        reader.onload = () => {
          const img = new Image();
          img.onload = () => {
            const canvas = canvasRef.current;
            const ctx = canvas.getContext('2d');
            const offscreenCtx = offscreenCanvasRef.current.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            offscreenCtx.clearRect(0, 0, offscreenCanvasRef.current.width, offscreenCanvasRef.current.height);
            offscreenCtx.drawImage(img, 0, 0, offscreenCanvasRef.current.width, offscreenCanvasRef.current.height);
            setHistory([{ type: 'image', img, x: 0, y: 0, width: canvas.width, height: canvas.height }]);
          };
          img.src = reader.result;
        };
        reader.readAsDataURL(file);
      }} />
      <main className={`container mx-auto p-4 ${isDraggingOver ? 'drag-over-screen' : ''}`}>
        <header className="text-center mb-4 heading">
          <h1 className="text-3xl font-bold">AI Whiteboard</h1>
          <p>Draw, erase, add shapes, and more!</p>
        </header>
        <section className="whiteboard flex flex-col items-center relative">
          <canvas
            ref={canvasRef}
            className="border-2 border-gray-300 mb-4 w-full max-w-4xl"
            style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'top left' }}
          ></canvas>
          <div className="controls flex flex-wrap gap-4 justify-center bg-gray-100 p-4 rounded-lg shadow-md">
            <div className="toolbar-section flex items-center gap-2">
              <button
                onClick={() => selectTool('brush')}
                className={`px-2 py-1 rounded flex items-center gap-1 ${
                  tool === 'brush' ? 'bg-[#4535C1] text-white' : 'bg-gray-200 text-gray-800'
                } hover:bg-[#36C2CE] hover:text-white transition-colors text-sm`}
                title="Brush Tool"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="tool-icon"
                >
                  <path d="M15 5h6M18 2v6M3 21l3-3-1-3 6-1 1 3 3 1-3 3z" />
                </svg>
                Brush
              </button>
              <select
                value={brushType}
                onChange={(e) => setBrushType(e.target.value)}
                className="px-1 py-1 rounded border border-gray-300 text-xs"
                title="Brush Type"
              >
                <option value="round">Round</option>
                <option value="square">Square</option>
              </select>
            </div>
            <div className="toolbar-section">
              <button
                className={`px-2 py-1 rounded flex items-center gap-1 ${
                  ['eraser', 'area-eraser', 'stroke-eraser'].includes(tool)
                    ? 'bg-[#4535C1] text-white'
                    : 'bg-gray-200 text-gray-800'
                } hover:bg-[#36C2CE] hover:text-white transition-colors text-sm`}
                title="Eraser Tools"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="tool-icon"
                >
                  <path d="M7 21l4-4 10-10-4-4-10 10-4 4h4zM15 5l4 4" />
                </svg>
                Eraser
              </button>
              <div className="dropdown-menu">
                <button
                  onClick={() => selectTool('eraser')}
                  className="w-full px-3 py-1 text-left text-xs hover:bg-[#36C2CE] hover:text-white flex items-center gap-1"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M7 21l4-4 10-10-4-4-10 10-4 4h4zM15 5l4 4" />
                  </svg>
                  Regular Eraser
                </button>
                <button
                  onClick={() => selectTool('area-eraser')}
                  className="w-full px-3 py-1 text-left text-xs hover:bg-[#36C2CE] hover:text-white flex items-center gap-1"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
                    <path d="M3 3l18 18" />
                  </svg>
                  Area Eraser
                </button>
                <button
                  onClick={() => selectTool('stroke-eraser')}
                  className="w-full px-3 py-1 text-left text-xs hover:bg-[#36C2CE] hover:text-white flex items-center gap-1"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M6 6l12 12M6 12h12" />
                  </svg>
                  Stroke Eraser
                </button>
              </div>
            </div>
            <div className="toolbar-section">
              <button
                className={`px-2 py-1 rounded flex items-center gap-1 ${
                  ['rectangle', 'circle', 'line'].includes(tool)
                    ? 'bg-[#4535C1] text-white'
                    : 'bg-gray-200 text-gray-800'
                } hover:bg-[#36C2CE] hover:text-white transition-colors text-sm`}
                title="Shape Tools"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="tool-icon"
                >
                  <rect x="3" y="3" width="18" height="12" rx="2" ry="2" />
                </svg>
                Shapes
              </button>
              <div className="dropdown-menu">
                <button
                  onClick={() => selectTool('rectangle')}
                  className="w-full px-3 py-1 text-left text-xs hover:bg-[#36C2CE] hover:text-white flex items-center gap-1"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect x="3" y="3" width="18" height="12" rx="2" ry="2" />
                  </svg>
                  Rectangle
                </button>
                <button
                  onClick={() => selectTool('circle')}
                  className="w-full px-3 py-1 text-left text-xs hover:bg-[#36C2CE] hover:text-white flex items-center gap-1"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <circle cx="12" cy="12" r="9" />
                  </svg>
                  Circle
                </button>
                <button
                  onClick={() => selectTool('line')}
                  className="w-full px-3 py-1 text-left text-xs hover:bg-[#36C2CE] hover:text-white flex items-center gap-1"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <line x1="3" y1="21" x2="21" y2="3" />
                  </svg>
                  Line
                </button>
              </div>
            </div>
            <div className="toolbar-section">
              <button
                onClick={() => selectTool('fill')}
                className={`px-2 py-1 rounded flex items-center gap-1 ${
                  tool === 'fill' ? 'bg-[#4535C1] text-white' : 'bg-gray-200 text-gray-800'
                } hover:bg-[#36C2CE] hover:text-white transition-colors text-sm`}
                title="Fill Tool"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="tool-icon"
                >
                  <path d="M19 14l-5 5-2-7-7-2 5-5zM5 19h14v-6H5z" />
                </svg>
                Fill
              </button>
            </div>
            <div className="toolbar-section flex items-center gap-2">
              <label className="flex items-center gap-1">
                <span className="text-xs">Color:</span>
                <input
                  type="color"
                  value={brushColor}
                  onChange={handleColorChange}
                  className="w-6 h-6"
                />
              </label>
              <label className="flex items-center gap-1 relative">
                <span className="text-xsprt">Size:</span>
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={brushSize}
                  onChange={handleBrushSizeChange}
                  className="w-16"
                />
                {showSizeOverlay && (
                  <div className="size-overlay absolute top-[-25px] left-1/2 transform -translate-x-1/2 bg-[#4535C1] text-white text-xs px-1 py-0.5 rounded">
                    {brushSize}px
                  </div>
                )}
              </label>
            </div>
            <div className="toolbar-section flex gap-1">
              <button
                onClick={clearCanvas}
                className="px-2 py-1 rounded bg-red-500 text-white hover:bg-red-600 transition-colors"
                title="Clear Canvas"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="tool-icon"
                >
                  <path d="M3 3h18v18H3zM9 9l6 6M15 9l-6 6" />
                </svg>
              </button>
            </div>
            <div className="toolbar-section flex gap-1">
              <button
                onClick={() => selectTool('zoom-in')}
                className={`px-2 py-1 rounded flex items-center gap-1 ${
                  tool === 'zoom-in' ? 'bg-[#4535C1] text-white' : 'bg-gray-200 text-gray-800'
                } hover:bg-[#36C2CE] hover:text-white transition-colors text-sm`}
                title="Zoom In"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="tool-icon"
                >
                  <circle cx="11" cy="11" r="8" />
                  <line x1="21" y1="21" x2="16.65" y2="16.65" />
                  <line x1="11" y1="8" x2="11" y2="14" />
                  <line x1="8" y1="11" x2="14" y2="11" />
                </svg>
              </button>
              <button
                onClick={() => selectTool('zoom-out')}
                className={`px-2 py-1 rounded flex items-center gap-1 ${
                  tool === 'zoom-out' ? 'bg-[#4535C1] text-white' : 'bg-gray-200 text-gray-800'
                } hover:bg-[#36C2CE] hover:text-white transition-colors text-sm`}
                title="Zoom Out"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="tool-icon"
                >
                  <circle cx="11" cy="11" r="8" />
                  <line x1="21" y1="21" x2="16.65" y2="16.65" />
                  <line x1="8" y1="11" x2="14" y2="11" />
                </svg>
              </button>
            </div>
          </div>
          <div className="flex justify-center mt-4">
            <button
              onClick={saveDrawing}
              disabled={isLoading}
              className="px-4 py-2 rounded flex items-center gap-2 bg-green-600 text-white hover:bg-green-700 disabled:bg-gray-400 transition-colors shadow-lg text-base"
              title="Upload Drawing"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="tool-icon"
              >
                <path d="M3 15v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4M17 9l-5-5-5 5M12 18V5" />
              </svg>
              Upload Drawing
            </button>
          </div>
        </section>
        <section ref={resultRef} className="result mt-4"></section>
        <div className={`loader ${isLoading ? '' : 'hidden'}`}>
          <div className="spinner"></div>
        </div>
      </main>
    </div>
  );
}

function App() {
  const isAuthenticated = !!localStorage.getItem('token');

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route
        path="/whiteboard"
        element={isAuthenticated ? <Whiteboard /> : <Navigate to="/login" />}
      />
      <Route path="/" element={<Navigate to="/login" />} />
    </Routes>
  );
}

export default App;