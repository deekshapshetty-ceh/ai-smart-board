import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './Navbar.css';

function Navbar({ onImageUpload }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user')) || {};

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        {/* Logo and title */}
        <div className="navbar-brand">
          <Link to="/whiteboard" className="navbar-logo-link">
            <div className="navbar-logo">
              <span>W</span>
            </div>
            <h1 className="navbar-title">AI Whiteboard</h1>
          </Link>
        </div>

        {/* Desktop navigation */}
        <div className="navbar-desktop">
          <div className="navbar-email">{user.name.toUpperCase()}</div>
          
          <label className="navbar-upload">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M3 15v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4M17 9l-5-5-5 5M12 18V5" />
            </svg>
            Upload Image
            <input
              type="file"
              accept="image/*"
              onChange={(e) => onImageUpload(e.target.files[0])}
              className="navbar-upload-input"
            />
          </label>

          <button
            onClick={handleLogout}
            className="navbar-logout"
          >
            Logout
          </button>
        </div>

        {/* Mobile menu button */}
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="navbar-mobile-button"
        >
          <svg
            className={`navbar-mobile-icon ${isMenuOpen ? 'hidden' : 'block'}`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M4 6h16M4 12h16M4 18h16"
            />
          </svg>
          <svg
            className={`navbar-mobile-icon ${isMenuOpen ? 'block' : 'hidden'}`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>
      </div>

      {/* Mobile menu */}
      <div className={`navbar-mobile ${isMenuOpen ? 'open' : ''}`}>
        <div className="navbar-mobile-content">
          <div className="navbar-mobile-email">{user.email}</div>
          
          <label className="navbar-mobile-upload">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M3 15v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4M17 9l-5-5-5 5M12 18V5" />
            </svg>
            Upload Image
            <input
              type="file"
              accept="image/*"
              onChange={(e) => onImageUpload(e.target.files[0])}
              className="navbar-mobile-upload-input"
            />
          </label>

          <button
            onClick={handleLogout}
            className="navbar-mobile-logout"
          >
            Logout
          </button>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;